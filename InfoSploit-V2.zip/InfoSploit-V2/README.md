
## ★ Description:

InfoSploit is a simple python script to Information Gathering 

```markdown

# ★ How to use:
sudo su
cd InfoSploit
chmod +x install
./install

Run in Terminal 

Infosploit

(To run in Android you do not install file Run direct python2 Infosploit)
```
## ★ Properties :

    DNS Lookup 
    Whois Lookup
    GeoIP Lookup
    Subnet Lookup
    Port Scanner
    Extract Links 
    Zone Transfer
    HTTP Header
    Host Finder
    Robots.txt
    IP-Locator
    Traceroute
    Host DNS Finder
    Revrse IP Lookup
    Collection Email
    Subdomain Finder 
    Install & Update
    About Me 
    Exit




